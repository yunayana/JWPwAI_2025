export default function Home() {
  return (
    <main>
      <h1 style={{ color: 'white', textAlign: 'center' }}>
        Laboratorium nr 11 - projekt startowy
      </h1>
    </main>
  );
}
